import 'dart:async';

import 'package:get/get.dart';
import 'package:my_app/core/data/model/app_exception.dart';
import '../../../core/domain/entity/asset_entity.dart';
import '../../../core/domain/entity/location_entity.dart';
import '../../../core/domain/use_case/get_assets_usecase.dart';
import '../../../core/domain/use_case/get_locations_use_case.dart';

class AssetController extends GetxController {
  final GetLocationsUseCase _getLocationsUseCase;
  final GetAssetsUseCase _getAssetsUseCase;

  String companyId = '';

  final RxList<LocationEntity> locations = <LocationEntity>[].obs;
  final RxList<AssetEntity> assets = <AssetEntity>[].obs;
  final RxList<AssetEntity> filteredAssets = <AssetEntity>[].obs;
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxString searchQuery = ''.obs;
  final RxBool filterEnergySensor = false.obs;
  final RxBool filterCritical = false.obs;
  final selectedLocation = ''.obs;

  AssetController(this._getAssetsUseCase, this._getLocationsUseCase);

  Timer? _debounce;

  void onSearchQueryChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      searchQuery.value = query;
      applyFilters();
    });
  }

  @override
  void onInit() {
    super.onInit();
    companyId = Get.arguments;
    fetchAssetsAndLocations();
  }

  Future<void> fetchAssetsAndLocations() async {
    isLoading(true);
    errorMessage('');
    try {
      final fetchedLocations = await _getLocationsUseCase(companyId);
      final fetchedAssets = await _getAssetsUseCase(companyId);

      locations.value = fetchedLocations.data ?? [];
      assets.value = fetchedAssets.data ?? [];

      applyFilters();
    } on AppException catch (_) {
      errorMessage('Failed to load assets and locations');
    } finally {
      isLoading(false);
    }
  }

  void applyFilters() {
    List<AssetEntity> tempFilteredAssets = assets;

    if (searchQuery.isNotEmpty) {
      final query = searchQuery.value.toLowerCase();
      tempFilteredAssets = tempFilteredAssets.where((asset) {
        final String assetName = asset.name.toLowerCase();
        final String locationName = locations
            .firstWhere(
              (location) => location.id == asset.locationId,
              orElse: () => LocationEntity(name: '', id: ''),
            )
            .name
            .toLowerCase();

        return assetName.contains(query) || locationName.contains(query);
      }).toList();
    }

    // Apply location filter
    if (selectedLocation.isNotEmpty) {
      tempFilteredAssets = tempFilteredAssets
          .where((asset) => asset.locationId == selectedLocation.value)
          .toList();
    }

    // Apply energy sensor filter
    if (filterEnergySensor.value) {
      tempFilteredAssets = tempFilteredAssets
          .where((asset) => asset.sensorType == 'energy')
          .toList();
    }

    // Apply critical status filter
    if (filterCritical.value) {
      tempFilteredAssets =
          tempFilteredAssets.where((asset) => asset.status == 'alert').toList();
    }

    filteredAssets.value = tempFilteredAssets;
  }

  void toggleEnergySensorFilter() {
    filterEnergySensor.value = !filterEnergySensor.value;
    applyFilters(); // Ensure this method is called after toggling the filter
  }

  void toggleCriticalFilter() {
    filterCritical.value = !filterCritical.value;
    applyFilters(); // Ensure this method is called after toggling the filter
  }
}
