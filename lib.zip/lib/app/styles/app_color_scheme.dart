import 'package:flutter/material.dart';

class AppColorScheme {
  static const Color background = Color(0xFF17192D);
  static const Color primary = Color(0xFF007BFF);
}
