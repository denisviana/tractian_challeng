abstract class StorageKeys {
  static const String token = 'token';
}
