class Environment {
  Environment._();

  static const baseUrlDev = '';
  static const baseUrlProd = '';
}
